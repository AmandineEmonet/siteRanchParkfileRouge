<footer class="footer pt-5 pb-5 w-100 py-4 flex-shrink-0 container-fluid" id="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
        <div class="container py-4">
            <div class="row gy-4 gx-5 text-centerm-0 p-0">
                <div class="col-lg-4 col-md-6 m-0 p-0">
                    <p class="nav-item mb-3"><a class="nav-link" href="./index.php"><img class="logoAccueil" src="./image/RanchLogoTranspAccueilJaune.png" alt="" ></a></p>

                </div>
                
                <div class="col-lg-4 col-md-6 m-0 p-0">
                    <ul class="list-unstyled text-muted">
                        <li><h5 class="nav-link px-2 text-center text-white">Où nous trouver:</h5></li>
                        <li><h6 class="nav-link px-2 text-center text-custom2">avenue du Parc</h6></li>
                        <li><h6 class="nav-link px-2 text-center text-custom2">Occitanie</h6></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6 m-0 p-0">
                    <ul class="list-unstyled text-muted">
                        <li><h5 class="nav-link px-2 text-center text-white">Nous contacter:</h5></li>
                        <li><h6 class="nav-link px-2 text-center text-custom2">05 05 05 05 05</h6></li>
                        <li><h6 class="nav-link px-2 text-center text-custom2">contact@ranchpark.com</h6></li>
                    </ul>
                </div>
            </div>

        </div>
        <div class="container py-4">
            <div class="row gy-4 gx-5 text-center m-0 p-0">
                <div class="col-lg-12 col-md-6 m-0">
                            <p class="text-center text-white ">&copy; Ranch Park 2021 - CGV - Règlement intérieur - Mentions Légales</p>
                </div>
            </div>
        </div>
</footer>